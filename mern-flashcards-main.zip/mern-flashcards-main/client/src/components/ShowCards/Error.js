import React from "react";

const Error = (props) => <div>Error: {props.errorContent} </div>;

export default Error;
